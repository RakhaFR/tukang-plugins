import Link from 'next/link';
import { ArrowRight, LayoutGrid, Cpu, ShieldCheck } from 'lucide-react';

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-gray-950 text-gray-100 flex flex-col justify-between">
      {/* Hero Section */}
      <main className="flex-1 flex flex-col items-center justify-center text-center px-4 max-w-4xl mx-auto py-20">
        <div className="mb-6 inline-flex items-center gap-2 bg-gray-900 border border-gray-800 px-4 py-1.5 rounded-full text-sm text-sky-400">
          <Cpu size={16} />
          <span>TheoTown Plugin Manager v1.0</span>
        </div>

        <h1 className="text-5xl md:text-7xl font-extrabold tracking-tight mb-6">
          <span className="text-red-500 block">TUKANG</span>
          <span className="bg-gradient-to-r from-sky-400 to-emerald-400 bg-clip-text text-transparent">
            PLUGIN
          </span>
        </h1>

        <p className="text-gray-400 text-lg md:text-xl mb-10 max-w-2xl leading-relaxed">
          Platform terintegrasi untuk mencari, memantau, dan mengunduh plugin serta aset kustom berkualitas tinggi untuk kota digital kamu di game <strong>TheoTown</strong>. 
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link 
            href="/plugins" 
            className="flex items-center gap-2 bg-sky-500 hover:bg-sky-600 text-white font-semibold px-8 py-4 rounded-xl shadow-lg shadow-sky-500/20 transition-all transform hover:-translate-y-0.5"
          >
            Get Started
            <ArrowRight size={20} />
          </Link>
          <a 
            href="#features" 
            className="flex items-center gap-2 bg-gray-900 hover:bg-gray-800 border border-gray-800 px-8 py-4 rounded-xl font-semibold transition-all"
          >
            Pelajari Fungsi
          </a>
        </div>
      </main>

      {/* Grid Fitur Kecil di Bawah */}
      <section id="features" className="bg-gray-900/50 border-t border-gray-900 py-12 px-4">
        <div className="max-w-5xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="flex gap-4 items-start">
            <div className="p-3 bg-sky-500/10 rounded-lg text-sky-400">
              <LayoutGrid size={24} />
            </div>
            <div>
              <h3 className="font-bold text-lg mb-1">Manajemen Folder</h3>
              <p className="text-gray-400 text-sm">Organisasi file terstruktur dari cloud penyimpanan langsung ke server lokal.</p>
            </div>
          </div>
          <div className="flex gap-4 items-start">
            <div className="p-3 bg-red-500/10 rounded-lg text-red-400">
              <ShieldCheck size={24} />
            </div>
            <div>
              <h3 className="font-bold text-lg mb-1">Bebas Error & Duplikat</h3>
              <p className="text-gray-400 text-sm">Penyaringan ketat untuk memastikan plugin yang diunduh 100% aman dijalankan.</p>
            </div>
          </div>
          <div className="flex gap-4 items-start">
            <div className="p-3 bg-emerald-500/10 rounded-lg text-emerald-400">
              <Cpu size={24} />
            </div>
            <div>
              <h3 className="font-bold text-lg mb-1">Instalasi Otomatis</h3>
              <p className="text-gray-400 text-sm">Panduan instalasi lokal yang praktis untuk pengguna pemula maupun mahir.</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}