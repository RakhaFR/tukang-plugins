import { NextRequest, NextResponse } from 'next/server';
import { drive } from '@/lib/googleDrive';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    // Jika ada parameter folderId dari frontend, pakai itu. Jika tidak, pakai Root Folder ID
    const folderId = searchParams.get('folderId') || process.env.GOOGLE_DRIVE_ROOT_FOLDER_ID;

    if (!folderId) {
      return NextResponse.json({ success: false, error: 'Root Folder ID tidak ditemukan' }, { status: 400 });
    }

    // Mengambil item di dalam folderId yang aktif
    const response = await drive.files.list({
      q: `'${folderId}' in parents and trashed = false`,
      fields: 'files(id, name, mimeType, size, webViewLink)',
      orderBy: 'folder, name', // Menampilkan folder dulu baru file
    });

    const items = response.data.files || [];

    // Pisahkan mana yang folder dan mana yang file asli
    const subFolders = items.filter(item => item.mimeType === 'application/vnd.google-apps.folder');
    const files = items.filter(item => item.mimeType !== 'application/vnd.google-apps.folder');

    return NextResponse.json({
      success: true,
      data: {
        currentFolderId: folderId,
        subFolders,
        files
      }
    });
  } catch (error: any) {
    console.error('Error fetching from Google Drive:', error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}